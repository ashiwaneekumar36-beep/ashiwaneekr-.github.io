import json
import os

# File where data will be stored
FILE_NAME = "S:/Python/Student Management System/students.json"
USER_FILE = "S:/Python/Student Management System/users.json"


# ------------------ LOAD DATA ------------------
def load_data():
    if not os.path.exists(FILE_NAME):
        return []

    with open(FILE_NAME, "r") as file:
        return json.load(file)


# ------------------ SAVE DATA ------------------
def save_data(data):
    with open(FILE_NAME, "w") as file:
        json.dump(data, file, indent=4)


# ------------------ ADD STUDENT ------------------
def add_student():
    students = load_data()

    name = input("Enter name: ")
    roll = input("Enter roll number: ")
    marks = float(input("Enter marks: "))

    student = {
        "name": name,
        "roll": roll,
        "marks": marks
    }

    students.append(student)
    save_data(students)

    print("Student added successfully!\n")


# ------------------ VIEW STUDENTS ------------------
def view_students():
    students = load_data()

    if not students:
        print("No records found.\n")
        return

    print("\n============== Student Details ==================")
    for s in students:
        print(f"\n Name: {s['name']}\n Roll: {s['roll']}\n Marks: {s['marks']}\n")
    print()


# ------------------ SEARCH STUDENT ------------------
def search_student():
    students = load_data()
    roll = input("Enter roll number to search: ")

    for s in students:
        if s["roll"] == roll:
            print("=========== Student Data ==========\n")

            for key, value in s.items():
                if key != "password":   # password hide karo
                    print(f"{key.capitalize()}: {value}")
            return

    print("Student not found.\n")


# ------------------ DELETE STUDENT ------------------
def delete_student():
    students = load_data()
    roll = input("Enter roll number to delete: ")

    new_list = [s for s in students if s["roll"] != roll]

    if len(new_list) == len(students):
        print("Student not found.\n")
    else:
        save_data(new_list)
        print("Student deleted.\n")


# ------------------ UPDATE STUDENT ------------------
def update_student():
    students = load_data()
    roll = input("Enter roll number to update: ")

    for s in students:
        if s["roll"] == roll:
            s["name"] = input("Enter new name: ")
            s["marks"] = float(input("Enter new marks: "))
            save_data(students)
            print("Updated successfully.\n")
            return

    print("Student not found.\n")


# ------------------ SORT STUDENTS ------------------
def sort_students():
    students = load_data()

    choice = input("Sort by (1) Name (2) Marks: ")

    if choice == "1":
        students.sort(key=lambda x: x["name"])
    elif choice == "2":
        students.sort(key=lambda x: x["marks"])

    for s in students:
        print(s)
    print()


# ---------------------  current user profile ----------
def view_own_data(user):
    print("\n===== YOUR DATA =====")

    for key, value in user.items():
        if key != "password":   # password hide karo
            print(f"{key.capitalize()}: {value}")
    
    return
# ------------------ REPORT ------------------
def report(user):
    students = load_data()

    if not students:
        print("No data.\n")
        return
    
    for u in students:
        if u["roll"]==user["roll"]:
            data=u
            break
 
    total = sum(s["marks"] for s in students)
    avg = total / len(students)

    topper = max(students, key=lambda x: x["marks"])

    print(f"Average Marks: {avg}")
    print(f"Topper: {topper['name']} ({topper['marks']})\n")


# ------------------ LOGIN ------------------
def login():
    if not os.path.exists(USER_FILE):
        print("No users found. Please register first.")
        return None

    with open(USER_FILE, "r") as students:
        data = json.load(students)

    attempts = 3

    while attempts > 0:
        username = input("Enter username: ")
        password = input("Enter password: ")

        for users in data:
            if users["username"] == username and users["password"] == password:
                print("Login successful!\n")
                return users

        attempts -= 1
        print(f"Wrong! attempts left {attempts}")

    print("Account locked!")
    return None


# ------------------ REGISTER ------------------
def register():
    users = []

    if os.path.exists(USER_FILE):
        with open(USER_FILE, "r") as f:
            users = json.load(f)

    name = input("Enter Your Name :- ")
    roll = input("Enter your roll_no :- ")
    username = input("Enter your username :- ")

    while True:
        password = input("Enter your password :- ")
        if len(password) <= 6:
            print("Password is too weak! Re-enter the password")
        else:
            break

    role = input("Enter role (admin/student): ").lower()

    admin_data = {
        "name": name,
        "roll": roll,
        "username": username,
        "password": password,
        "role": role
    }

    users.append(admin_data)

    with open(USER_FILE, "w") as f:
        json.dump(users, f, indent=4)

    print("Registration successful!")
    print("\nPlease Login\n")
    return login()


# ------------------ USER ------------------
def user():
    print("\n===================== Welcome to Student Management System ====================\n")

    while True:
        print("\n1 Login")
        print("2 Register")

        choice = int(input("Enter your Choice :- "))

        if choice == 1:
            return login()
        elif choice == 2:
            return register()
        else:
            print("❌ Invalid Choice")


# ------------------ STUDENT MENU ------------------
def student_menu(user):
    while True:
        print("\n===== STUDENT MENU =====")
        print("1. View Students")
        print("2. Search Student")
        print("3. View Report")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
           view_own_data(user)
        elif choice == "2":
            search_student()
        elif choice == "3":
            report()
        elif choice == "4":
            print("Exiting Student Menu...")
            break
        else:
            print("Invalid choice!\n")


# ------------------ MAIN MENU ------------------
def main():
    users = user()
    if not users:
        return

    while True:
        if users["role"] == "admin":
            print("\n===== ADMIN MENU =====")
            print("1. Add Student")
            print("2. View Students")
            print("3. Search Student")
            print("4. Update Student")
            print("5. Delete Student")
            print("6. Sort Students")
            print("7. Report")
            print("8. Exit")

            choice = input("Enter choice: ")

            if choice == "1":
                add_student()
            elif choice == "2":
                view_students()
            elif choice == "3":
                search_student()
            elif choice == "4":
                update_student()
            elif choice == "5":
                delete_student()
            elif choice == "6":
                sort_students()
            elif choice == "7":
                report()
            elif choice == "8":
                print("Exiting...")
                break
            else:
                print("Invalid choice!\n")

        else:
            student_menu(users)
            break


# Run program
main()